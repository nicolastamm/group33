package com.example.nicol.dronflyvis;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.common.util.ArrayUtils;

import java.lang.reflect.Array;
import java.util.stream.DoubleStream;


public class act1 extends AppCompatActivity
{
    private Button nextBtn;
    private EditText inputText;
    private Boolean inputOk = false;
    private RadioButton mavicBtn;
    private RadioButton bepobBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act1);

        nextBtn = (Button) findViewById(R.id.act1next);
        mavicBtn = (RadioButton) findViewById(R.id.radioButton4);
        bepobBtn = (RadioButton) findViewById(R.id.radioButton3);

        mavicBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(mavicBtn.isChecked())
                {
                    bepobBtn.setChecked(false);

                }
                else
                {
                    bepobBtn.setChecked(true);
                }
            }
        });

        bepobBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(bepobBtn.isChecked())
                {
                    mavicBtn.setChecked(false);
                }
                else
                {
                    mavicBtn.setChecked(true);
                }

            }
        });

        //InfoButtonPopUp
        Button infoButton = (Button) findViewById(R.id.act1info);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),infoPopUpAct.class);
                startActivity(intent);
            }
        });

        EditText inputTextCheck = (EditText) findViewById(R.id.editText3);
        inputTextCheck.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2)
            {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2)
            {

            }

            @Override
            public void afterTextChanged(Editable editable)
            {
                if(editable.toString().trim().length() > 0 && Double.parseDouble(editable.toString()) > 100)
                {
                    AlertDialog.Builder dBuilder = new AlertDialog.Builder(act1.this);
                    dBuilder.setTitle("Zulässige Flughöhe überschritten!");
                    dBuilder.setMessage("Die Eingestellte Flughöhe ist über 100 Meter, dies ist ein Verstoß gegen das Gesetz!")
                            .setCancelable(true)
                            .setPositiveButton("Verstanden", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.cancel();
                                }
                            });

                    AlertDialog alertDialog = dBuilder.create();
                    alertDialog.setTitle("Flughöhe überschritten!");
                    alertDialog.show();
                }
            }
        });
    }

    public float[] getInputValues()
    {
        int[] inputIds = {R.id.editText, R.id.editText3, R.id.editText4};
        int i = 0;
        float[] inputValues = new float[]{-1,-1,-1};
        for(int id : inputIds)
        {
            inputText = (EditText) findViewById(id);
            if(isEmpty(inputText))
            {
                inputText.setError("Sie müssen dieses Feld korrekt ausfüllen!");
            }
            else
            {
                inputValues[i] = Float.parseFloat("0" + inputText.getText().toString());
                i++;
            }
        }
        return inputValues;
    }

    public boolean isEmpty(EditText text)
    {
        if(TextUtils.isEmpty(text.getText().toString()))
        {
            return true;
        }
        return false;
    }

    /**
     Der Skelet für Alelrt !
     Also Jungs, hier sit schon mal unser erster Allert.
     Dafür habe ich oben eine neue Variable hinzugefügt (inputOk).

     Wenn der Wert von dieser gleich False ist, dann kommt der Alert mit dem anderen Button zum wegclicken.
     Ist der Input ok, dann soll auch alles wie wir es hatten ablaufen.

     also To_Do hier :

     Input-man erstellt sich jetzt die neue Funktion(mit den alten, die der schon hatte) mit mehreren Abfragen in den Feldern.
     War alles ok? dann wird auch der inputOk auf "true" gesetzt und NUR dann.
     Und ja, um die Funktion überhaupt zu starten muss man erst auf next drücken, also ruf die einfach in act_1_next auf;

     Design-man kann sich jetzt gedanken machen über das Aussehen von Alert.
     Solche Sachen wie Bilder hinzufügen, Messege als Source speichern, farben und und und :)

     LG
     Android Integrator

     */
    public boolean contains(float[] array, float value)
    {
        for(int i = 0; i < array.length; i++)
        {
            if(array[i] == value)
            {
                return true;
            }
        }
        return false;
    }
    //Funktion um die warnings auszugeben statt diesem copy-paste zeug aus den 2 methoden
    public void issueWarning()
    {

    }

    public void act_1_next(View view)
    {
        float invalidInput = -1.0f;
        float[] inputValues = getInputValues();

        if(!contains(inputValues, invalidInput) && inputValues[1] <= 100)
        {
            inputOk = true;
        }

        if(inputOk)
        {
            Intent intent = new Intent(this, act2.class);
            intent.putExtra("com.example.nicol.dronflyvis.INPUT_VALUES", inputValues);
            startActivity(intent);
        }

        else
            {
                AlertDialog.Builder dBuilder = new AlertDialog.Builder(act1.this);

                dBuilder.setTitle("Bitte die Eingabefelder ausfühlen");
                dBuilder.setMessage("Es ist in Ihrem Interesse die Felder sorgfältig auszufüllen!")
                        .setCancelable(false)
                        .setPositiveButton("Ja, Entschuldigung :(", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                                }
                        });
                AlertDialog alertDialog = dBuilder.create();
                alertDialog.setTitle("Nix Da, gib alles ordenlich an!");
                alertDialog.show();
         }

    }





}

