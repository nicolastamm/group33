package swp;

import java.util.ArrayList;

/**
 * @author Johannes
 */
public class Control implements InterfaceRoutepoints
{
	private ArrayList<ArrayList<Node>> grid;
	private static int height;
	private static Node startNode;

	//initialize a Nodegrid which is a ArrayList of ArrayLists of Nodes
	Control()
	{
		grid = new ArrayList<ArrayList<Node>>();
		height = 100;
	}

	Control(ArrayList<ArrayList<Node>> grid)
	{
		this.grid = grid;
		height = 100;
	}

	Control(ArrayList<ArrayList<Node>> grid, int height)
	{
		this.grid = grid;
		Control.height = height;
	}

	/**
	 * @param start is the position of the pilot in the field
	 * @param numberOfLists
	 */
	public void setStartNode(Node start, int numberOfLists)
	{
		startNode = start;
		for(int i = 1; i <= numberOfLists; ++i)
		{
			grid.add(new ArrayList<Node>());
		}
	}

	/**
	 * @return the startNode
	 */
	public static Node getStartNode() 
	{
		return startNode;
	}

	/**
	 * @return the height
	 */
	public static int getHeight() 
	{
		return height;
	}

	/**
	 * 
	 * @param index
	 * @param toAdd
	 */
	public void addNode(int index, Node toAdd)
	{
		ArrayList<Node> tmp = grid.get(index);
		
		tmp.add(toAdd);
	}

	/**
	 * @return grid
	 */
	@Override
	public ArrayList<ArrayList<Node>> getRoute()
	{
		return grid;
	}

	/**
	 * @return startNode
	 */
	@Override
	public Node getStartingpoint()
	{
		return startNode;
	}
	
}

