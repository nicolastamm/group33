package swp;

import java.util.ArrayList;

/**
 * @author Martin
 */
public interface InterfaceRoutepoints
{
	public ArrayList<ArrayList<Node>> getRoute();
    public Node getStartingpoint();
}
