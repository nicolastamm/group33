package swp;


/**
 * @author Johannes
 * @author Martin
 */
public class Node
{
	private double longitude;
	private double latitude;
	
	/**
	 * Sets the Latitude and the Longitude of a Node
	 * @param latitude to set
	 * @param longitude to set
	 */
	Node(double latitude, double longitude)
	{
		setLongitude(longitude);
		setLatitude(latitude);
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude()
	{
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(double longitude)
	{
		this.longitude = longitude;
	}

	/**
	 * @return the latitude
	 */
	public double getLatitude()
	{
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(double latitude)
	{
		this.latitude = latitude;
	}
	
	/**
	 * Compare the latitude of this Node with an other Node
	 * @param compare the Node to compare with this Node
	 * @return true iff the latitude of this Node is greater than the latitude of the Node to compare
	 */
	public boolean gth(Node compare)
	{
		return this.latitude > compare.getLatitude();
	}
	
	/**
	 * Compare the latitude of this Node with an other Node
	 * @param compare the Node to compare with this Node
	 * @return true iff the latitude of this Node is lower than the latitude of the Node to compare
	 */
	public boolean lth(Node compare)
	{
		return this.latitude < compare.getLatitude();
	}
	
	/**
	 * Compare the latitude of this Node with an other Node
	 * @param compare the Node to compare with this Node
	 * @return true iff the latitude of this Node is greater equal than the latitude of the Node to compare
	 */
	public boolean geq(Node compare)
	{
		return this.latitude >= compare.getLatitude();
	}
	
	/**
	 * Compare the latitude of this Node with an other Node
	 * @param compare the Node to compare with this Node
	 * @return true iff the latitude of this Node is lower equal than the latitude of the Node to compare
	 */
	public boolean leq(Node compare)
	{
		return this.latitude <= compare.getLatitude();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "Node (latitude=" + latitude + ", longitude=" + longitude + ")";
	}
}
