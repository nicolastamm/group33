package com.example.nicol.dronflyvis;

import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class act3 extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    Marker startMarker;

    private float pos;
    private float zoom;
    private double lat;
    private double lng;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act3);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        if(getIntent().hasExtra("com.example.nicol.dronflyvis.BEARING"))
        {
            pos = getIntent().getExtras().getFloat("com.example.nicol.dronflyvis.BEARING");
            zoom = getIntent().getExtras().getFloat("com.example.nicol.dronflyvis.ZOOM");
            lat = Double.parseDouble(getIntent().getExtras().getString("com.example.nicol.dronflyvis.LAT"));
            lng = Double.parseDouble(getIntent().getExtras().getString("com.example.nicol.dronflyvis.LNG"));

        }
    }
    public void changeType(View view)
    {
        switch(mMap.getMapType())
        {
            case GoogleMap.MAP_TYPE_NORMAL:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                break;
            case GoogleMap.MAP_TYPE_SATELLITE:
                mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                break;
            case GoogleMap.MAP_TYPE_TERRAIN:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                break;
            case GoogleMap.MAP_TYPE_HYBRID:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        mMap = googleMap;
        if (mMap != null)
        {
           mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener()
           {
               @Override
               public void onMapClick(LatLng latLng)
               {
                   act3.this.setMarker("Local",latLng.latitude, latLng.longitude);
               }
           });
        }
        CameraUpdate nloc = CameraUpdateFactory.newLatLngZoom(
                new LatLng(lat, lng), zoom);
        mMap.animateCamera(nloc);
    }



    Circle sichtFeld;
    private void setMarker(String locality, double lat, double lng)
    {
        if(startMarker!= null)
        {
            removeMarkerandCircle();

        }
        MarkerOptions options = new MarkerOptions()
                .title(locality)
                .draggable(true)
                .position(new LatLng(lat,lng))
                .snippet("StartPos");

        startMarker= mMap.addMarker(options);
        sichtFeld = drawCircle(new LatLng(lat, lng));

    }

    private Circle drawCircle(LatLng latLng)
    {
        CircleOptions options = new CircleOptions()
                .center(latLng)
                .radius(500)
                .fillColor(0x33FF0000)
                .strokeColor(Color.BLUE)
                .strokeWidth(3);

        return mMap.addCircle(options);
    }

    private void removeMarkerandCircle()
    {
        startMarker.remove();
        startMarker = null;
        sichtFeld.remove();
        sichtFeld = null;
    }

    public void act_3_next(View view)
    {

        //If no marker is set the app crashes here
        Intent intent = new Intent(this, act4.class);
        if(startMarker != null)
        {
            intent.putExtra("com.example.nicol.dronflyvis.MARKER_LNG", startMarker.getPosition().longitude);
            intent.putExtra("com.example.nicol.dronflyvis.MARKER_LAT", startMarker.getPosition().latitude);
        }

        startActivity(intent);
    }

    public void act_3_back(View view)
    {
        onBackPressed();
    }
}

