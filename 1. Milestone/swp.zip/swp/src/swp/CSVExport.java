package swp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author Johannes
 */
public class CSVExport 
{
	/**
	 * Exports an CSV File, which contains all necessary information for the DroneTour
	 * @param route contains the route points to export
	 */
	public static void exportCSV(ArrayList<Node> route)
	{
		SimpleDateFormat format = new SimpleDateFormat("dd.MM.yy' 'HH.mm");			//
		Date currentTime = new Date();
		String day = "" + format.format(currentTime);
		
		File csv = new File("C:" + File.separator + "Users" + File.separator + "Jojo" + File.separator + "OneDrive"
				+ File.separator + "Dokumente" + File.separator + "Route" + day + ".csv");
		String content;
		content = "latitude,longitude,altitude.m.,heading.deg.,curvesize.m.,rotationdir,gimbalmode,"
				+ "gimbalpitchangle,actiontype1,actionparam1,actiontype2,actionparam2,actiontype3,"
				+ "actionparam3,actiontype4,actionparam4,actiontype5,actionparam5,actiontype6,actionparam6,"
				+ "actiontype7,actionparam7,actiontype8,actionparam8,actiontype9,actionparam9,actiontype10,"
				+ "actionparam10,actiontype11,actionparam11,actiontype12,actionparam12,actiontype13,"
				+ "actionparam13,actiontype14,actionparam14,actiontype15,actionparam15\r\n";

		// iterates through the whole list and writes every Nodes Longitude and Latitude
		for (int i = 0; i < route.size(); ++i)
		{
			Node add = route.get(i);
			content += add.getLatitude() + "," + add.getLongitude() + "," + Control.getHeight()
					+ ",0,0,0,0,0,1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0\r\n";
		}
		
		try
		{
			BufferedWriter output = new BufferedWriter(new FileWriter(csv));

			// iterates through the whole list and writes every Nodes Longitude and Latitude
			 
			output.write(content);
			output.close(); // done writing out

		} catch (IOException e)
		{
			e.printStackTrace();
		}

	}
}

