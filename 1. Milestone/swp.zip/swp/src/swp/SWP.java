package swp;

public class SWP
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Control ctrl = new Control();
		TravelingSalesman tsm = new TravelingSalesman();
		
		ctrl.setStartNode(new Node(47.7686641399725,8.99640740637146), 3);    	//Startpunkt
		
		ctrl.addNode(0, new Node(47.7677989154743,8.99642040706515));		//Liste Mitte
		ctrl.addNode(0, new Node(47.767931960391,8.99641780696081));
		ctrl.addNode(0, new Node(47.7680650052992,8.99641520683927));
		ctrl.addNode(0, new Node(47.7681980501989,8.99641260670053));
		ctrl.addNode(0, new Node(47.7683310950899,8.99641000654459));
		ctrl.addNode(0, new Node(47.7684641399725,8.99640740637146));
		
		ctrl.addNode(1, new Node(47.7677941001767,8.9958947769815));		//Liste Links
		ctrl.addNode(1, new Node(47.7679271450791,8.99589217551578));
		ctrl.addNode(1, new Node(47.7680601899729,8.99588957403284));
		ctrl.addNode(1, new Node(47.7681932348581,8.9958869725327));
		ctrl.addNode(1, new Node(47.7683262797348,8.99588437101534));
		ctrl.addNode(1, new Node(47.7684593246029,8.99588176948078));
		
		ctrl.addNode(2, new Node(47.7683359079239,8.99693564216358));		//Liste Rechts
		ctrl.addNode(2, new Node(47.7682028630184,8.9969382409581));
		ctrl.addNode(2, new Node(47.7680698181044,8.99694083973543));
		ctrl.addNode(2, new Node(47.7679367731818,8.99694343849557));
		ctrl.addNode(2, new Node(47.7678037282506,8.99694603723852));
		ctrl.addNode(2, new Node(47.7684641399725,8.99693564216358));
	/*	
		ctrl.addNode(3, new Node(47.7683359079239,8.99743564216358));		//Liste RechtsRechts
		ctrl.addNode(3, new Node(47.7682028630184,8.9974382409581));
		ctrl.addNode(3, new Node(47.7680698181044,8.99744083973543));
		ctrl.addNode(3, new Node(47.7679367731818,8.99744343849557));
		ctrl.addNode(3, new Node(47.7678037282506,8.99744603723852));
		ctrl.addNode(3, new Node(47.7684641399725,8.99743564216358));*/
		
		CSVExport.exportCSV(tsm.travelingSalesman(ctrl.getRoute()));
	}
	
}
