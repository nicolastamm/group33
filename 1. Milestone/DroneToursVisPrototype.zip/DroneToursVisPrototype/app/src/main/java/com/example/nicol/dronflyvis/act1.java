package com.example.nicol.dronflyvis;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Array;


public class act1 extends AppCompatActivity
{
    private Button nextBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act1);

        nextBtn = (Button) findViewById(R.id.act1next);
    }
    public float[] getInputValues()
    {
        int[] inputIds = {R.id.editText, R.id.editText3, R.id.editText4};
        int i = 0;
        float[] inputValues = new float[3];
        for(int id : inputIds)
        {
            EditText inputText = (EditText) findViewById(id);
            if(isEmpty(inputText))
            {
                inputText.setError("Sie müssen dieses Feld ausfüllen!");
            }
            else
            {
                inputValues[i] = Float.parseFloat("0" + inputText.getText().toString());
                i++;
            }

        }

        return inputValues;
    }

    public boolean isEmpty(EditText text)
    {
        if(TextUtils.isEmpty(text.getText().toString()))
        {
            return true;
        }
        return false;
    }
    public void act_1_next(View view)
    {
            Intent intent = new Intent(this, act2.class);
            intent.putExtra("com.example.nicol.dronflyvis.INPUT_VALUES", getInputValues());
            startActivity(intent);
    }

}

