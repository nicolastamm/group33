package com.example.nicol.dronflyvis;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class buch_slider extends PagerAdapter{
    Context context;
    LayoutInflater layoutInflater;

    public buch_slider(Context context){
        this.context = context;
    }

    public int[] images_toslide = {
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher
    };

    public String[] act_headers = {
            "Act1",
            "Act2",
            "Act3",
            "Act4"
    };

    public String[] act_discr = {
            "Act1 descr hier",
            "Act2 descr hier",
            "Act3 descr hier",
            "Act4 descr hier"
    };


    @Override
    public int getCount() {
        return act_headers.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == (RelativeLayout) object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.buch_slide_view,container,false);

        ImageView slideImage = (ImageView)view.findViewById(R.id.buch_act_image);
        TextView header = (TextView)view.findViewById(R.id.buch_act_header);
        TextView discr = (TextView)view.findViewById(R.id.buch_act_discription);

        slideImage.setImageResource(images_toslide[position]);
        header.setText(act_headers[position]);
        discr.setText(act_discr[position]);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout)object);
    }
}
